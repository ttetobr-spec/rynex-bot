@echo off
setlocal
cd /d "%~dp0"
title Rynex Discord Bot
if not exist node_modules (
  echo Instalando dependencias...
  call npm install
  if errorlevel 1 (
    echo Falha ao instalar dependencias.
    pause
    exit /b 1
  )
)
if not exist .env (
  echo ERRO: crie um arquivo .env nesta pasta antes de iniciar.
  echo Use .env.example como modelo.
  pause
  exit /b 1
)
echo Iniciando Rynex... Nao feche esta janela.
:loop
call npm start
set EXITCODE=%errorlevel%
echo O bot foi encerrado com codigo %EXITCODE%. Reiniciando em 5 segundos...
timeout /t 5 /nobreak >nul
goto loop
